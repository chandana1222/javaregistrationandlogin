package com.springboot.tutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeRegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
